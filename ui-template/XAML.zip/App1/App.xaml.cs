using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Windows;
using System.Windows.Controls;

namespace App1;

public sealed partial class App : Application
{
    public App()
    {
        InitializeComponent();

        var mainPage = new MainPage();
        Window.Current.Content = mainPage;
    }
}
