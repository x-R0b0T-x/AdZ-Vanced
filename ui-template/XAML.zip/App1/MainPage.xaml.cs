﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Windows;
using System.Windows.Controls;

namespace App1;

public partial class MainPage : Page
{
    private int _clickCount;

    public MainPage()
    {
        InitializeComponent();
    }

    private void OnButtonClick(object sender, RoutedEventArgs e)
    {
        if (sender is Button button)
        {
            button.Content = $"Clicked count: {++_clickCount}";
        }
    }
}
